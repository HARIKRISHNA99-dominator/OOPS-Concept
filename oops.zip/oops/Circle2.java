import java.util.*;
class Circle {
protected double radius;
Circle(double r){
radius = r;
}
Circle(){
radius =0;
}
public double getRadius() {
Scanner sc = new Scanner(System.in);
return(radius);
}
public void setRadius(){
System.out.println("The radius is set as: " + radius);
}
public double getArea() {
double area = 3.14*radius*radius;
return(area);
}
}
class Cylinder extends Circle {
double height;
Circle o;
Cylinder(){
Scanner s = new Scanner(System.in);
height=0;
System.out.println("Enter height: ");
height = s.nextInt();
System.out.println("Enter radius: ");
double r1 = s.nextInt();
o = new Circle(r1);
radius = o.getRadius();
}
public double getHeight() {
System.out.println("Height is "+ height);
return(height);
}
public void setHeight(){
System.out.println("The height is set as "+ height);
o.setRadius();
}
public double getArea(){
double Area= 2*3.14*radius*height + 2*o.getArea();
System.out.println("Area is " + Area);
return(Area);
}
}
class Circle2{
public static void main(String args[])
{
Circle c = new Circle();
Cylinder y = new Cylinder();
y.getHeight();
y.setHeight();
y.getArea();
}
}