import java.util.*;
public class generic
{
	public static void main(String[] args) {
	    Scanner s = new Scanner(System.in);
	    System.out.println("Enter the number of elements in the Integer array");
	    int n = s.nextInt();
		Integer[] arr = new Integer[n];
		System.out.println("Enter the elements of the array");
		for(int i = 0;i<arr.length;i++)
		{
		    arr[i] = s.nextInt();
		}
		numElements(arr,4);
		System.out.println("Enter the number of elements in the Double array");
		int m = s.nextInt();
	    Double[] arr1 = new Double[n];
		System.out.println("Enter the elements of the array");
		for(int i = 0;i<arr1.length;i++)
		{
		    arr1[i] = s.nextDouble();
		}
		numElements(arr1,4.0);
		
		
		
	}
	public static <T extends Comparable>void numElements(T[] arr,T elem)
	{
	    int count = 0;
	    for(T element: arr)
	    {
	        if(element.compareTo(elem)>0)
	        count++;
	    }
	    System.out.println("The number of elements in the array greater than "+elem+" are "+count);
	}
}