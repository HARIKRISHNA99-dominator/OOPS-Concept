import java.util.*;
public class Genericone<E extends Comparable<E>> {
public static < E > void printArray( E[] inputArray ) {
// Display array elements
for(E element : inputArray) {
System.out.printf("%s ", element);
}
System.out.println();
}
public static <E extends Number> void countArray(E[] inputArray, int elem) {
int i = 0;
for (E element : inputArray) {
if(elem < element.intValue ())
i++;
}
System.out.println(i);
}
public static void main(String args[]) {
Scanner sc = new Scanner(System.in);
Integer[] intArray = { 1, 2, 3, 4, 5 };
System.out.println("\nArray contains:");
printArray(intArray);
int elem=0;
System.out.println("Enter the specified number: ");
elem = sc.nextInt();
countArray(intArray, elem);
}
}