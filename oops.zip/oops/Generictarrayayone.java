import java.util.*;
class X<Number>{
     Number f[];
     static double g[];
    X(Number f[]){
        this.f=f;
        for(int i=0;i<f.length;i++){
            g[i]=Double.parseDouble(f.toString());
        }
    }
    public static double Max(){
        double max=0;
        for(int i=0;i<g.length;i++){
            if(max<g[i]){
                max=g[i];
            }
        }
        return max;
    }
}
public class generictwo
{
    public static void main(String[] args) {
        Scanner ob=new Scanner(System.in);
        int n=ob.nextInt();
        Integer a[]=new Integer[n];
        for(int i=0;i<n;i++){
            a[i]=ob.nextInt();
        }
        X<Integer> as=new X<Integer>(a);
        System.out.println(as.Max());
    }
}