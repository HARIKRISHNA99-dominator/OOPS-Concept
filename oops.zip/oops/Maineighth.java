import java.util.*;
class Card
{
    Scanner ob=new Scanner(System.in);
  int cardnumber,pin;
  Card(int cardnumber,int pin)
  {
      this.cardnumber=cardnumber;
      this.pin=pin;
  }
  public boolean validatePin(int i,int j)
  {
      if(i==cardnumber&&j==pin)
      {
          return true;
      }
      else
      {
          return false;
      }
  }
}
class Account{
    int acc_number;
    Card fg;
    int balance;
    Account(int acc_number,Card fg,int balance)
    {
        this.acc_number=acc_number;
        this.fg=fg;
        this.balance=balance;
    }
    public void makeWithdrawal(int amount) {
        if (fg.validatePin(acc_number, fg.pin)) {

            if (amount > balance) {
                System.out.println("Amount exceeded balance");
            } else {
                balance = balance - amount;
                System.out.println("Your balance is " + balance);
            }
        }
        else
        {
            System.out.println("Invalid account credentials");
        }
    }
}
class ATM{
       Scanner ob=new Scanner(System.in);
       int bal;
       int acc;
       int pin;
       int amount;
       ATM(int acc,int pin,int bal,int amount)
       {
           this.acc=acc;
           this.pin=pin;
           this.bal=bal;
           this.amount=amount;
       }
      public void withdraw()
    {
      Card wq=new Card(acc,pin);
      Account qe=new Account(acc,wq,bal);
      qe.makeWithdrawal(amount);
    }
}
public class Maineighth {

    public static void main(String[] args) {
        Scanner ob=new Scanner(System.in);
        System.out.println("Saving account and pin");
        System.out.println("Account:");
        int x=ob.nextInt();
        System.out.println("Enter pin:");
        int y=ob.nextInt();
        System.out.println("Input balance:");
        int z=ob.nextInt();
        int a[]={x,y,z};
        System.out.println("ATM---INPUT ACCOUNT AND PASSWORD");
        int accx=ob.nextInt();
        int passx=ob.nextInt();
        int balance=0;
        if(accx==a[0]&&passx==a[1])
        {
            balance=a[2];   //The matrix a can be made multi dimensional with each row carrying each acc details. Here we are dealing with only one account
        }
        System.out.println("Input amount to be withdrawn");
        int am=ob.nextInt();
        ATM ds=new ATM(accx,passx,balance,am);
        ds.withdraw();
    }
}