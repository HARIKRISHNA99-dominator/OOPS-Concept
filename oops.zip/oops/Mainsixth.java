import java.util.*;
public class Mainsixth {
    static int N = 0;

    static boolean isMagicSquare(int mat[][]) {
        N = mat.length;
        int sum = 0, sum2 = 0;
        for (int i = 0; i < N; i++)
            sum = sum + mat[i][i];
        for (int i = 0; i < N; i++)
            sum2 = sum2 + mat[i][N - 1 - i];
        if (sum != sum2)
            return false;
        for (int i = 0; i < N; i++) {
            int rowSum = 0;
            for (int j = 0; j < N; j++)
                rowSum += mat[i][j];

            if (rowSum != sum)
                return false;
        }
        for (int i = 0; i < N; i++) {

            int colSum = 0;
            for (int j = 0; j < N; j++)
                colSum += mat[j][i];
            if (sum != colSum)
                return false;
        }

        return true;
    }

    public static void main(String[] args) 
    { 
        Scanner in = new Scanner(System.in);
int n = in.nextInt();

int mat[][]=new int[n][n];
for (int i = 0 ; i < n; i++)
{
for (int j = 0 ; j<n;j++)
{
mat[i][j] = in.nextInt();
}}
  
        if (isMagicSquare(mat)) 
            System.out.println("Magic Square"); 
        else
            System.out.println("Not a magic" + 
                                    " Square"); 
    }
}