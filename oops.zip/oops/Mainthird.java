class Reverse{
    int num;
    static int find(int num) 
    { 
        int rev_num = 0; 
        while(num > 0) 
        { 
            rev_num = rev_num * 10 + num % 10; 
            num = num / 10; 
        } 
        return rev_num; 
    } 
}

class ReverseR extends Reverse{
  
}

public class Mainthird{
    public static void main(String[] args) {
    Scanner ob=new Scanner(System.in);

        System.out.println("Input test case");
      int test=ob.nextInt();

  int rev_num1 = num1.find(test);
  System.out.println(rev_num1);
 }
}