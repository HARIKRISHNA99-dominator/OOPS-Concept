import java.util.*;
public class SquareMatrixmain{
public static void main(String[] args){
Scanner ob = new Scanner(System.in);
System.out.println("Enter number of rows of matrix : ");
int m = ob.nextInt();
System.out.println("Enter number of columns of matrix : ");
int n = ob.nextInt();
int[][] matrix = new int[m][n];
System.out.println("Enter the elements of matrix: ");
for(int i=0; i<m; i++){
for(int j=0; j<n;j++){
matrix[i][j] = ob.nextInt();
}
}
try{
if(m != n){
throw new NotASquareMatrix();
} else {
throw new SymmetricMatrix();
}
}
catch(NotASquareMatrix a){
System.out.println(a);
}
catch(SymmetricMatrix a){
System.out.println(a);
}
}
}
class NotASquareMatrix extends Exception {
public String toString(){
return("Not a square matrix");
}
}
class SymmetricMatrix extends Exception {
public String toString(){
return("It is a square matrix");
}
}
