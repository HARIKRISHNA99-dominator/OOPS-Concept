import java.util.*;
class THREADONE{
  public static void main(String args[]) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the number");
    int n=sc.nextInt();
    T1 a=new T1(n);
    Thread t1=new Thread(a);
    t1.start();
    T2 b=new T2(n);
    Thread t2=new Thread(b);
    t2.start();
  }
}
class T1 implements Runnable{
  int n;
  T1(int n){
    this.n=n;
  }
  public void run() 
  {
    int rev=0;
     while(n!= 0) {
             rev = rev*10+(n%10);
              n = n/10;
          }
     System.out.println("Reversed Number: " + rev);
  }
}
class T2 implements Runnable {
  int n;
  T2(int n){
    this.n=n;
  }
  public void run() {
    int total = 0, r;   
     int temp = n; 
    while(n>0)   
     { r = n % 10; 
       total = (total*10)+r;
     n = n/10; }
    if(temp==total)
     System.out.println("It is a Palindrome number");
     else
       System.out.println("Not a palindrome");
  }
}