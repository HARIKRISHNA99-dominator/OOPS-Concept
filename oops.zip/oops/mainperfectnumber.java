import java.util.*;
class MyException extends Exception{
	int c;
	MyException( int d){
		c=d;
	}
	public String toString(){
		return (c+ " is a perfext number....");
	}
}


public class perfectnumber{
public static void main(String args[]){
Scanner ob = new Scanner(System.in);
int i ,a,sum=0;
System.out.println("enter a number : ");
a=ob.nextInt();
for(i=1;i<a;i++){
	if(a%i==0){
		sum=sum+i;
	}
	
}
try{
	if(sum==a){
		throw new MyException(a);
		
	}
	else{
		System.out.format("not a perfect number ....:",a);
	}
}
catch(MyException b){
	System.out.println(b);
}
}

}