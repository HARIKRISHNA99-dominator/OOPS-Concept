import java.util.*;
public class newJavaFile1
{
public static void main(String arg[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter no of rows :");
int m=sc.nextInt();
System.out.println("Enter no of columns :");
int n=sc.nextInt();
int mat[][]=new int [m][n];
System.out.println("Enter the elements :");
int i,j;
for (i=0; i<m; i++)
{
for (j=0; j<n; j++)
{
mat[i][j]=sc.nextInt();
}
}
try
{
if(m!=n)
{
throw new NotASQuareMatrix();
}
else
{
if (CheckSym(mat,m,n))
{
System.out.println("Its a square and symmetric Matrix");
}
else
{
throw new AsymmetricMatrixFoundException();
}
}
}
catch(NotASQuareMatrix e)
{
System.out.println(e);
}
catch(AsymmetricMatrixFoundException e)
{
System.out.println(e);
}
}
static void transpose(int m[][], int n[][], int r, int c)
{
int i;
int j;
for (i=0; i<r; i++)
{
for (j=0; j<c; j++)
{
n[i][j]=m[j][i];
}
}
}
static boolean CheckSym(int m[][],int r,int c)
{
int i;
int j;
int n[][]=new int[r][c];
transpose(m,n,r,c);
for (i=0; i<r; i++)
{
for (j=0; j<c; j++)
{
if(n[i][j]!=m[i][j])
return false;
}
}
return true;
}
}
class AsymmetricMatrixFoundException extends Exception
{
public String toString()
{
return("AsymmetricMatrixFoundException");
}
}
class NotASQuareMatrix extends Exception
{
public String toString()
{
return("NotASQuareMatrix");
}
}